package interfaces;

import java.lang.*;

public interface PatientTransactions
{
	public boolean addmoney(double amount);
	public boolean costmoney(double amount);
}
